var { createScript } = pc;

class VirtualJoystick {
    /**
     * @type {AppBase}
     */
    app;

    /**
     * @type {Entity}
     */
    entity;

    /**
     * @param {AppBase} app  - The application.
     * @param {Entity} entity - The entity.
     * @param {Entity} stick - The stick entity.
     * @param {string} enableEvent - The event to enable the joystick.
     * @param {string} moveEvent - The event to move the joystick.
     * @param {string} disableEvent - The event to disable the joystick.
     */
    constructor(app, entity, stick, enableEvent, moveEvent, disableEvent) {
        this.app = app;
        this.entity = entity;

        this.app.on(enableEvent, function (x, y) {
            this.entity.setLocalPosition(x, -y, 0);
            stick.setLocalPosition(x, -y, 0);

            this.entity.element.enabled = true;
            stick.element.enabled = true;
        }, this);

        this.app.on(moveEvent, function (x, y) {
            stick.setLocalPosition(x, -y, 0);
        }, this);
        
        this.app.on(disableEvent, function () {
            this.entity.element.enabled = false;
            stick.element.enabled = false;
        }, this);
    }
}

// SCRIPTS

const VirtualJoystickScript = createScript('virtualJoystick');

VirtualJoystickScript.attributes.add('stick', { type: 'entity' });
VirtualJoystickScript.attributes.add('enableEvent', { type: 'string' });
VirtualJoystickScript.attributes.add('moveEvent', { type: 'string' });
VirtualJoystickScript.attributes.add('disableEvent', { type: 'string' });

// initialize code called once per entity
VirtualJoystickScript.prototype.initialize = function() {
    this.joystick = new VirtualJoystick(this.app, this.entity, this.stick, this.enableEvent, this.moveEvent, this.disableEvent);
};
